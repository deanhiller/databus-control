#!/bin/bash

play-1.2.5/play run --%demo -Xmx1024M 
#-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=1044
