package models.message;

public enum DatasetType {
	STREAM, RELATIONAL_TABLE, TIME_SERIES;
} // DatasetType
