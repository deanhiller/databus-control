package controllers.modules2;

import controllers.modules2.framework.procs.MetaInformation;

public class AggregationProcessorOld extends AggregationProcessor {

	@Override
	public MetaInformation getGuiMeta() {
		return null;
	}

}
