package controllers.modules2;

import controllers.modules2.framework.ProcessedFlag;

public class EmptyFlag implements ProcessedFlag {

	@Override
	public void setSocketRead(boolean on) {
		
	}


}
