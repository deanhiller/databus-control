package controllers.modules2.framework.http;

public class HttpCompleted extends AbstractHttpMsg {

	public HttpCompleted(String url, HttpListener listener) {
		super(url, listener);
	}

}
