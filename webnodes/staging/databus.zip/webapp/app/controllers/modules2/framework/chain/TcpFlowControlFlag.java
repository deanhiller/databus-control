package controllers.modules2.framework.chain;

import controllers.modules2.framework.ProcessedFlag;

public class TcpFlowControlFlag implements ProcessedFlag {

	@Override
	public void setSocketRead(boolean on) {
		
	}

}
