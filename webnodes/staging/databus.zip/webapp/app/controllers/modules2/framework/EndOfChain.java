package controllers.modules2.framework;

import controllers.modules2.framework.procs.ProcessorSetup;


/** 
 * Marker interface
 * @author dhiller2
 *
 */
public interface EndOfChain extends ProcessorSetup {

}
