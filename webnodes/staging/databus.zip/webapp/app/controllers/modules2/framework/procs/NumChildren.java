package controllers.modules2.framework.procs;

public enum NumChildren {
	NONE("none"), ONE("one"), MANY("many");

	private String code;

	private NumChildren(String code) {
		this.code = code;
	}

	public Object getCode() {
		return null;
	}
}
