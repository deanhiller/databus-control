package controllers.modules2.framework;

public enum Direction {

	PUSH, PULL, EITHER, NONE;
}
