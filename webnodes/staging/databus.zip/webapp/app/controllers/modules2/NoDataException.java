package controllers.modules2;

public class NoDataException extends RuntimeException {

	public NoDataException() {
	}

	public NoDataException(String arg0) {
		super(arg0);
	}

	public NoDataException(Throwable arg0) {
		super(arg0);
	}

	public NoDataException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
