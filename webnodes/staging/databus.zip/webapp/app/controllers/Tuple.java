package controllers;

public class Tuple {

	public String key;
	public String value;
	
	public Tuple(String valStr, String keyStr) {
		this.value = valStr;
		this.key = keyStr;
	}
}
