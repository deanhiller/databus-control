#!/bin/bash

./play status --url=http://localhost:8080/
